
function [yEz, yHz, yErho, yEphi, yHrho, yHphi]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper, mu_lower, sigma_upper,...
    sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho)
e0= 8.854e-12;
u0= pi*4e-7;
w= 2*pi*f;
%% currenlty  a mess, too many redundancies needs to be cleaned up
kz= sqrt (k.^2- k_rho^2);
kz_upper= sqrt (k_upper.^2- k_rho^2);
kz_lower= sqrt (k_lower.^2- k_rho^2);
kz_0= kz_upper(1); % also equals kz_lower(1)
% eps_lower
% eps_upper
% input('')
eps= [fliplr(eps_lower) eps_upper(2:end)];
mu=[fliplr(mu_lower) mu_upper(2:end)];
sigma= [fliplr(sigma_lower) sigma_upper(2:end)];
%% determine the total reflection coefficients
[ R_TMp, R_TEp] = planewave_response_TGRS2(f,eps_upper, mu_upper,sigma_upper, d_upper, k_rho);
[ R_TMm, R_TEm] = planewave_response_TGRS2(f,eps_lower, mu_lower,sigma_lower, d_lower, k_rho);
%% determine wave amplitude at source
[ABp0, ABm0, CDp0, CDm0]= source_HED(f,I,len,k,k_rho,kz_0, R_TMp, R_TMm,R_TEp, R_TEm);
%% determination of the propagation matrix in logarithmic scale
[U_TM, V_TM, U_TE, V_TE]= calculate_prop_matrix_log(f, eps, mu, sigma, d,k_rho);
%% calculation of the amplitudes at each region
[ABp, ABm, CDp, CDm]= calculate_abcd(length(eps_upper), length(eps_lower), ABp0, ABm0, CDp0, CDm0, U_TM, U_TE, V_TM, V_TE);
%% determination of the region where the reciever is located
[med_idx,ABl, CDl, kzl]= determine_receiver_location2 (kz,d,m_idx, z, ABp, ABm, CDp, CDm);
eps_l= eps(med_idx)*e0;
mu_l= mu(med_idx)*u0;
% input('')
%% the term of Ez and Hz
yEz= (ABl(1)*exp(-1i*kzl*z)+ ABl(2)*exp(1i*kzl*z))*besselj(1, k_rho*rho);
yHz= (CDl(1)*exp(-1i*kzl*z)+ CDl(2)*exp(1i*kzl*z))*besselj(1, k_rho*rho);

%% from next on, the first component is the tm and the second component is the te component
%% the other terms of E
src_termAB= -1*ABl(1)*exp(-1i*kzl*z)+ ABl(2)*exp(1i*kzl*z);
src_termCD= CDl(1)*exp(-1i*kzl*z)+ CDl(2)*exp(1i*kzl*z);
besseldiff= besselj(0, k_rho*rho)- (1/(k_rho*rho))*besselj(0, k_rho*rho);

% calculation of erho
yErho= (1i* kzl/k_rho)*src_termAB * besseldiff + (1i*w*mu_l/(k_rho^2 *rho))...
    *src_termCD * besselj(1, k_rho*rho);

%calculation of ephi
yEphi= (1i*kzl*(k_rho^2*rho))*src_termAB *besselj(1, k_rho*rho) + ...
    (-1i*w*mu_l/k_rho)* src_termCD * besseldiff;

%% the other terms of H
src_termAB= ABl(1)*exp(-1i*kzl*z)+ ABl(2)*exp(1i*kzl*z);
src_termCD= -1*CDl(1)*exp(-1i*kzl*z)+ CDl(2)*exp(1i*kzl*z);

% calculation of Hrho
yHrho= (-1i*w*eps_l/(k_rho^2*rho))* src_termAB *besselj(1, k_rho*rho)+...
    (1i*kzl/k_rho)* src_termCD * besseldiff;

%calculation of hphi
yHphi = (1i*w*eps_l/k_rho)*src_termAB* besseldiff + ...
    (1i*kzl/(k_rho^2*rho))*src_termCD * besselj(1, k_rho*rho);




end