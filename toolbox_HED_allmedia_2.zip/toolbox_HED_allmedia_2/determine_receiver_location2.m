function [med_idx, ABl, CDl, kzl]= determine_receiver_location2 (kz,d,m_idx,z, ABp, ABm, CDp, CDm)
medium= m_idx(end);
for i = 1: length(d)
    if (z< d(i))
        medium= m_idx(i);
        break
    end
end
med_idx= i; % the medium index, which is used to get the epsilon and mu values
if z>0
    A= ABp(1,abs(medium)+1);
    B= ABp(2,abs(medium)+1);
    C= CDp(1,abs(medium)+1);
    D= CDp(2,abs(medium)+1);
else
    A= ABm(1,abs(medium)+1);
    B= ABm(2,abs(medium)+1);
    C= CDm(1,abs(medium)+1);
    D= CDm(2,abs(medium)+1);
end
ABl= [A; B];
CDl= [C; D];
kzl= kz(m_idx==medium);

end
