function [ABp, ABm, CDp, CDm]= calculate_abcd(len_up, len_dn, ABp0, ABm0, CDp0, CDm0, U_TM, U_TE, V_TM, V_TE) 
ABp= ABp0;
ABm= ABm0;
CDp= CDp0;
CDm= CDm0;

for i= 1: len_up -1
    ABp(:,i+1)=  convert_log_decimal(U_TM{i+len_dn-1})* ABp(:,i);
    CDp(:,i+1)=  convert_log_decimal(U_TE{i+len_dn-1})* CDp(:,i);
end
for i= 1:  len_dn-1
    ABm(:,i+1)=  convert_log_decimal(V_TM{end-len_up+2-i})* ABm(:,i);
    CDm(:,i+1)=  convert_log_decimal(V_TE{end-len_up+2-i})* CDm(:,i);
end
end
