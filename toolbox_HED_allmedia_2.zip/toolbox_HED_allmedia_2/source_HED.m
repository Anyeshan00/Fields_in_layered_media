function [ABp0, ABm0, CDp0, CDm0]= source_HED(f,I,len,k,k_rho,kz_0, R_TMp, R_TMm,R_TEp, R_TEm)

w= 2*pi*f;
e0= 8.854e-12;
u0= pi*4e-7;

E_Hed= 1i*I*len*k_rho^2/(4*pi*w*e0);
% E_Hed= k_rho^2; % the scaled form, to compare with tgrs code
H_Hed= 1i*I*len*k_rho^2/(4*pi*kz_0);
% H_Hed= k_rho^2/kz_0;% the scaled form to  compare with the tgrs code
denTM= (1- R_TMp*R_TMm);
denTE= (1- R_TEp*R_TEm);
A0p= E_Hed*R_TMp*(1-R_TMm)/ denTM;
A0m= -E_Hed*(1-R_TMp)/ denTM;
B0p= E_Hed*(1- R_TMm)/ denTM;
B0m= -E_Hed*R_TMm* ( 1- R_TMp)/ denTM;
C0p= H_Hed*R_TEp*(1+R_TEm)/ denTE;
C0m= H_Hed*(1+R_TEp)/ denTE;
D0p= H_Hed*(1+R_TEm)/ denTE;
D0m= H_Hed*R_TEm* ( 1+R_TEp)/ denTE;

ABp0= [A0p;B0p];
ABm0= [A0m;B0m];
CDp0= [C0p;D0p];
CDm0= [C0m;D0m];
end