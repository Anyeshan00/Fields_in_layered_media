function [eps_ud, mu_ud, sigma_ud, k, k_ud,d_ud, m_idx]= stratify_up_down...
    (f, eps, mu, sigma, d, d_idx)

    %% initializations
    w= 2*pi*f;
    e0= 8.854e-12;
    u0= pi*4e-7;
    eps_c= eps*e0+ 1i*sigma/(w);
    k= w*sqrt(mu.*eps_c*u0);
    
    % the upper media from the  source
    m_idx= [d_idx(1)-1 d_idx];
    eps_ud{1}= eps(m_idx>=0);
    mu_ud{1}= mu(m_idx>=0);
    sigma_ud{1}= sigma(m_idx>=0);
    k_ud{1}= k(m_idx>=0);
    d_ud{1}= d(d_idx>0);
    
    % the lower media from the  source
    eps_ud{2}= fliplr(eps(m_idx<=0));
    mu_ud{2}= fliplr(mu(m_idx<=0));
    sigma_ud{2}= fliplr(sigma(m_idx<=0));
    k_ud{2}= fliplr(k(m_idx<=0));
    d_ud{2}= (fliplr(d(d_idx<=0)));
end

   
