function [U_TM, V_TM, U_TE, V_TE]= calculate_prop_matrix_log(f, eps, mu, sigma, d,krho)
e0= 8.854e-12;
u0= pi*4e-7;
w= 2*pi*f;
eps= eps*e0+ 1i*sigma/w;
mu= mu*u0;
k= w*sqrt(eps.*mu);
kz= sqrt (k.^2 - krho^2);

for p= 1:length(eps)-1
    
    tempeps= 0.5*(kz(p+1)*eps(p)+kz(p)*eps(p+1))/(kz(p+1)*eps(p+1));
    tempmu= 0.5*(kz(p+1)*mu(p)+kz(p)*mu(p+1))/(kz(p+1)*mu(p+1));
    R_TMtemp= (kz(p+1)*eps(p)-kz(p)*eps(p+1))/(kz(p+1)*eps(p)+kz(p)*eps(p+1)) ;
    R_TEtemp= (kz(p+1)*mu(p)-kz(p)*mu(p+1))/(kz(p+1)*mu(p)+kz(p)*mu(p+1)) ;
    
    tempeps2= 0.5*(kz(p)*eps(p+1)+kz(p+1)*eps(p))/(kz(p)*eps(p));
    tempmu2= 0.5*(kz(p)*mu(p+1)+kz(p+1)*mu(p))/(kz(p)*mu(p));
    R_TMtemp2= (kz(p)*eps(p+1)-kz(p+1)*eps(p))/(kz(p+1)*eps(p)+kz(p)*eps(p+1)) ;
    R_TEtemp2= (kz(p)*mu(p+1)-kz(p+1)*mu(p))/(kz(p+1)*mu(p)+kz(p)*mu(p+1)) ;
    
    U_TM{p} = log(tempeps)+[(-1i*(kz(p)-kz(p+1))*d(p))  log(R_TMtemp)+(1i*(kz(p)+kz(p+1))*d(p));
        log(R_TMtemp)+(-1i*(kz(p)+kz(p+1))*d(p)) (1i*(kz(p)-kz(p+1))*d(p))];  
    V_TM{p} = log(tempeps2)+[(-1i*(kz(p+1)-kz(p))*d(p))  log(-R_TMtemp)+(1i*(kz(p+1)+kz(p))*d(p));
        log(-R_TMtemp)+(-1i*(kz(p+1)+kz(p))*d(p)) (1i*(kz(p+1)-kz(p))*d(p))];
 
    U_TE{p} = log(tempmu)+[(-1i*(kz(p)-kz(p+1))*d(p))  log(R_TEtemp)+(1i*(kz(p)+kz(p+1))*d(p));
        log(R_TEtemp)+(-1i*(kz(p)+kz(p+1))*d(p)) (1i*(kz(p)-kz(p+1))*d(p))];
    V_TE{p} = log(tempmu2)+[(-1i*(kz(p+1)-kz(p))*d(p))  log(R_TEtemp2)+(1i*(kz(p+1)+kz(p))*d(p));
        log(R_TEtemp2)+(-1i*(kz(p+1)+kz(p))*d(p)) (1i*(kz(p+1)-kz(p))*d(p))];
end

end