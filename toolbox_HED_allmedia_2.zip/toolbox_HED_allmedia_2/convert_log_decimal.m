function y= convert_log_decimal(A)
if iscell(A)
    A= cell2mat(A);
end
[row,col]= size(A);
for i= 1:row
    for j= 1:col
        y(i,j)= sum(exp(A(i,j)));
    end
end
end