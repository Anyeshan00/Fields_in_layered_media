function [sum,flag] = simpsons_routine(pointval, term1, term2, flag)
    if (pointval==0)
        sum= term1+term2;
    else
        sum= flag*term1+term2;
        if  (flag==3)
            flag=1;
        elseif (flag==1)
            flag=3;
        else
            dips('worng flagging')
        end
    end
end
