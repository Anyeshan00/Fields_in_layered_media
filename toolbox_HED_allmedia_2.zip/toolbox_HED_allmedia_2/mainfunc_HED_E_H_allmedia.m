
clc,
clear, close all

%% initialization (similar to the values of the paper in TGRS)

e0= 8.854e-12;
u0= pi*4e-7;

% assuming stratification  is along the  negative z axis only
% eps= [ 1  3.2   1   1];
% mu= ones(1, length(eps));
% losst= [5000 5 0 0];
% z= 2 ;
% GOTO LINE 38 TO INITIZLAIZE THE THICKNESS AND d VALUES

%_____________________________________________________
% if we assumed the stratification is along the positive z axis, then the
% input syntax is:
f= 8e6;
lambda=3e8/f;
eps= [ 1 3.2   1 1 ];
mu= ones(1, length(eps));
losst= [5000  .005  0 0];
z=0.08*lambda;
rho= 2*lambda;
%________________________________________________________________
% Both of them gave identical results


%preprocessing and other inputs
w= 2*pi*f;
sigma= losst.*eps*w*e0;
% sigma= [4 4 0];
I=1;
len= 1;

%% calculation of the fields along broadside direction for Hz, and Endfire direction, for Ez, for thicknesses and radial  distances
thickness= [4*lambda]; % a sample thickness of 2m, for  checking with different thickness, the value can be passed as array.
d= [-1*thickness 0 1];
d_idx= [-1 0 1 ];
%_____________________________________________________
% if the stratification is chosen to be along the  positive z axis
%              d= [-1 0 thickness];
%              d_idx= [0 1 2];
%_______________________________________________________

%% stratification into upper and lower medium with respect to
% the source
[eps_ud, mu_ud, sigma_ud,k, k_ud,d_ud, m_idx]= stratify_up_down...
    (f, eps, mu, sigma, d, d_idx);
eps_upper= eps_ud{1};
mu_upper = mu_ud{1};
sigma_upper= sigma_ud{1};
k_upper= k_ud{1};
d_upper= d_ud{1};
eps_lower= eps_ud{2};
%         input('mainfuntion')
mu_lower = mu_ud{2};
sigma_lower= sigma_ud{2};
k_lower= k_ud{2};
d_lower= d_ud{2};

%% simposons routine to calculate Hz
k_rho= -0.01i/rho;
tol= 1e-6; % the value of tolerance, similar to tgrs
delkrho = 0.05/rho; % along the sommerfeld path, similar to tgrs
err= Inf;
flag= 3;
datapoint=0;
sumIntegrandHz=0;
while(err>tol)
    temp= sumIntegrandHz;
    [~,term1,~, ~, ~, ~]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper,mu_lower, sigma_upper,...
        sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho);
    [~,term2,~, ~, ~, ~]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper,mu_lower, sigma_upper,...
        sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho+delkrho);
    [sumval,flag]= simpsons_routine(datapoint, term1, term2, flag);
    sumIntegrandHz= sumIntegrandHz+sumval;
    err= abs((temp-sumIntegrandHz)/sumIntegrandHz);
    k_rho= k_rho+delkrho;
    datapoint= datapoint+1;
end
Hz= sumIntegrandHz*delkrho/3

%% simposons routine to calculate Ez
k_rho= -0.01i/rho;
tol= 1e-6; % the value of tolerance, similar to tgrs
delkrho = 0.05/rho; % along the sommerfeld path, similar to tgrs
err= Inf;
flag= 3;
datapoint=0;
sumIntegrandEz=0;
while(err>tol)
    temp= sumIntegrandEz;
    [term1,~,~, ~, ~, ~]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper,mu_lower, sigma_upper,...
        sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho);
    [term2,~,~, ~, ~, ~]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper,mu_lower, sigma_upper,...
        sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho+delkrho);
    [sumval,flag]= simpsons_routine(datapoint, term1, term2, flag);
    sumIntegrandEz= sumIntegrandEz+sumval;
    err= abs((temp-sumIntegrandEz)/sumIntegrandEz);
    k_rho= k_rho+delkrho;
    datapoint= datapoint+1;
end
Ez= sumIntegrandEz*delkrho/3

%% simpsons oroutine to calculate Erho
k_rho= -0.01i/rho;
tol= 1e-6; % the value of tolerance, similar to tgrs
delkrho = 0.05/rho; % along the sommerfeld path, similar to tgrs
err= Inf;
flag= 3;
datapoint=0;
sumIntegrandErho=0;
while(err>tol)
    temp= sumIntegrandErho;
    [~,~,term1, ~, ~, ~]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper,mu_lower, sigma_upper,...
        sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho);
    [~,~,term2, ~, ~, ~]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper,mu_lower, sigma_upper,...
        sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho+delkrho);
    [sumval,flag]= simpsons_routine(datapoint, term1, term2, flag);
    sumIntegrandErho= sumIntegrandErho+sumval;
    err= abs((temp-sumIntegrandErho)/sumIntegrandErho);
    k_rho= k_rho+delkrho;
    datapoint= datapoint+1;
end
Erho= sumIntegrandErho*delkrho/3

%% simpsons oroutine to calculate Ephi
k_rho= -0.01i/rho;
tol= 1e-6; % the value of tolerance, similar to tgrs
delkrho = 0.05/rho; % along the sommerfeld path, similar to tgrs
err= Inf;
flag= 3;
datapoint=0;
sumIntegrandEphi=0;
while(err>tol)
    temp= sumIntegrandEphi;
    [~,~,~,term1, ~, ~]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper,mu_lower, sigma_upper,...
        sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho);
    [~,~,~,term2, ~, ~]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper,mu_lower, sigma_upper,...
        sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho+delkrho);
    [sumval,flag]= simpsons_routine(datapoint, term1, term2, flag);
    sumIntegrandEphi= sumIntegrandEphi+sumval;
    err= abs((temp-sumIntegrandEphi)/sumIntegrandEphi);
    k_rho= k_rho+delkrho;
    datapoint= datapoint+1;
end
Ephi= sumIntegrandEphi*delkrho/3

%% simpsons oroutine to calculate Hrho
k_rho= -0.01i/rho;
tol= 1e-6; % the value of tolerance, similar to tgrs
delkrho = 0.05/rho; % along the sommerfeld path, similar to tgrs
err= Inf;
flag= 3;
datapoint=0;
sumIntegrandHrho=0;
while(err>tol)
    temp= sumIntegrandHrho;
    [~,~,~,~,term1, ~]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper,mu_lower, sigma_upper,...
        sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho);
    [~,~,~,~,term2, ~]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper,mu_lower, sigma_upper,...
        sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho+delkrho);
    [sumval,flag]= simpsons_routine(datapoint, term1, term2, flag);
    sumIntegrandHrho= sumIntegrandHrho+sumval;
    err= abs((temp-sumIntegrandHrho)/sumIntegrandHrho);
    k_rho= k_rho+delkrho;
    datapoint= datapoint+1;
end
Hrho= sumIntegrandHrho*delkrho/3

%% simpsons oroutine to calculate Hphi
k_rho= -0.01i/rho;
tol= 1e-6; % the value of tolerance, similar to tgrs
delkrho = 0.05/rho; % along the sommerfeld path, similar to tgrs
err= Inf;
flag= 3;
datapoint=0;
sumIntegrandHphi=0;
while(err>tol)
    temp= sumIntegrandHphi;
    [~,~,~, ~, ~,term1]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper,mu_lower, sigma_upper,...
        sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho);
    [~,~,~, ~, ~, term2]= calculate_E_H_krho (f,I, len, eps_upper, eps_lower, mu_upper,mu_lower, sigma_upper,...
        sigma_lower,d, d_upper, d_lower,m_idx,k, k_upper, k_lower, rho,z,k_rho+delkrho);
    [sumval,flag]= simpsons_routine(datapoint, term1, term2, flag);
    sumIntegrandHphi= sumIntegrandHphi+sumval;
    err= abs((temp-sumIntegrandHphi)/sumIntegrandHphi);
    k_rho= k_rho+delkrho;
    datapoint= datapoint+1;
end
Hphi= sumIntegrandHphi*delkrho/3







